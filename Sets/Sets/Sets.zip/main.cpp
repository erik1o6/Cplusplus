//main.cpp
//Written by: Erik Arfvidson

#include"Set.h"
using namespace std;

void main()
{
	insertStrings();
	system("pause");
}