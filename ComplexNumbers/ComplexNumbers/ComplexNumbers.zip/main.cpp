// main.cpp - Complex type testing main program entry point
//Written by Erik Arfvidson

#include <iostream>
#include "complex.h"

using namespace std;

void main()
{
	//a is an object; an object is an instance of the class
	//user defined type Complex IS a class
	Complex a(3,4), b(10,20);
	
	/* Changed to a(real,imagenay)
	//. is an operator, member access operator
	a.Re=1;
	a.Im=2;
	b.Re=10;
	b.Im=20;
	*/

	//c=a.+(b)


	//c = a. + (b);
	// +-*/ operations
	Complex c = a + b;
	Complex d = a - b;
	Complex multiplication = a * b;
	Complex division = a / b;
	//Complex e = a * b;
	//Complex f = a / b;
	// output test for Complex to Complex Operations
	cout<<"	   Welcome to the Complex Number Program"<<endl;
	cout<< "		Complex to Complex Operations"<<endl;
	cout<< "		  Written by: Erik Arfvidson"<<endl;
	cout << "Addition Test" << endl <<"a + b should print Re=13; Im=24: "<< c <<endl<<endl;
	cout << "Subtraction Test" << endl <<"a - b should print Re=-7; Im=-16: "<< d <<endl<<endl;
	cout << "Multiplication Test" << endl <<"a * b should print Re=-50; Im=100: "<< multiplication <<endl<<endl;
	cout << "Division Test" << endl <<"a / b should print Re=0.22; Im=-0.04: "<< division <<endl<<endl;
	cout<< "Absolute value of a is :"<<a.Absolute() <<endl;


	float x = 3.0f;

	// testing +-*/ operator overload that takes float for right
	Complex sum = c + x;
	Complex minus = c - x;
	Complex Fmultiplication = c * x;
	Complex Fdivision = c / x;
	// output test for Complex to Float Operations
	cout<<endl<< "		Complex to Float Operations"<<endl;
	cout<< "The Float number being tested is x = 3.0f and the value of c is Re=13; Im=24"<<endl;
	cout << "Addition Test" << endl <<"c + x should print Re=16; Im=24: "<< sum	 <<endl<<endl;
	cout << "Subtraction Test" << endl <<"c - x should print Re=10; Im=24: "<< minus <<endl<<endl;
	cout << "Multiplication Test" << endl <<"a * x should print Re=39; Im=72: "<< Fmultiplication <<endl<<endl;
	cout << "Division Test" << endl <<"c / x should print Re=4.33333; Im=8: "<< Fdivision <<endl<<endl;
	system("pause");
}