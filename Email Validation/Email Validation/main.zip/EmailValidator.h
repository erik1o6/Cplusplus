//EmailValidator.cpp   Email Validator____ Validates an email from a txt file outputs validity of email in another txt file
//Written By: Erik Arfvidson
# pragma once

#include <iostream>
#include <string>
#include <fstream> // responsible for file input/output
using namespace std;

//Email validation function
//false otherwise

bool IsValid(string email);

